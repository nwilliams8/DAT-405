//Create two variables that will store the new objects from the class Circle
let circleArray = [];
let arraySize = 1000;

function setup() {
  createCanvas(500, 500);
  colorMode(RGB);
  this.from = color(random(255), random(255), random(255));
  this.to = color(255, 255, 255);
  background(160);
  for (let i=0; i<arraySize; i++){
    circleArray[i] = new Circle(width/2, height/2, random(-0.1, 0.1), random(-0.1, 0.1), random(1, 10));
  }
}

function draw() {;
  for (let i=0; i<circleArray.length; i++){
    circleArray[i].moveFunction();
    circleArray[i].displayCircle();
  }
}

//Definition of the class Circle
class Circle{

  constructor(x, y, speedX, speedY, size){
    this.angle = 0
    //Setup of class' variables
    this.x = x;
    this.y = y;
    this.speedX = speedX;
    this.speedY = speedY;
    this.size = size;
    this.rd = random(255);
    this.grn = random(255);
    this.bl = random(255);
    this.a = 255;
  }

  //Class function that takes care of motion and collision
  moveFunction(){
    this.x = this.x + cos(this.angle)
    this.y = this.y + sin(this.angle)

    this.angle += this.speedX/2
    this.angle += this.speedY/2



    //Based on boundaries collision, reverse direction for x and y

  }

  //Class function that displays the ellipse
  displayCircle(){
    noStroke()
    fillcol = lerpColor(this.from, this.to, .5)
    fill(fillcol);
    ellipse(this.x, this.y, this.size, this.size);
  }
}
